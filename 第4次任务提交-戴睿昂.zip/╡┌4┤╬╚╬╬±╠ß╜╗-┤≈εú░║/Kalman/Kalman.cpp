#include <iostream>
#include <opencv2/opencv.hpp>
#include "Simulator.hpp"  

using namespace std;
using namespace cv;

template<typename T, int x>
class KalmanSimulator : public Simulator<T, x> {
private:
    KalmanFilter kf;

public:
    explicit KalmanSimulator(Eigen::Matrix<T, x, 1> x0, double variance,
                             Eigen::Matrix<T, x, 1> velocity = Eigen::Matrix<T, x, 1>::Zero())
            : Simulator<T, x>(x0, variance, velocity) {
        // 初始化卡尔曼滤波器
        kf = KalmanFilter(x, x, 0);
        kf.transitionMatrix = cv::Mat::eye(x, x, CV_32F);
        setIdentity(kf.measurementMatrix);
        setIdentity(kf.processNoiseCov, Scalar::all(1e-4));
        setIdentity(kf.measurementNoiseCov, Scalar::all(1e-1));
        setIdentity(kf.errorCovPost, Scalar::all(1));
    }

    Eigen::Matrix<T, x, 1> getKalmanFilteredMeasurement() {
        // 获取模拟器生成的测量值
        Eigen::Matrix<T, x, 1> measurement = this->getMeasurement();

        // 将Eigen类型转换为OpenCV的Mat类型
        Mat measurementMat = Mat(x, 1, CV_32F);
        for (int i = 0; i < x; ++i) {
            measurementMat.at<float>(i) = measurement(i, 0);
        }

        // 进行卡尔曼预测
        Mat prediction = kf.predict();

        // 更新卡尔曼滤波器
        Mat estimated = kf.correct(measurementMat);

        // 将Mat类型的估计值转换为Eigen类型
        Eigen::Matrix<T, x, 1> estimatedEigen;
        for (int i = 0; i < x; ++i) {
            estimatedEigen(i, 0) = estimated.at<float>(i);
        }

        return estimatedEigen;
    }
};

int main() {
    // 设置模拟器参数
    Eigen::Matrix<double, 2, 1> x0;
    x0 << 0, 0;
    double variance = 1.0;

    // 创建KalmanSimulator
    KalmanSimulator<double, 2> kalmanSimulator(x0, variance);

    // 创建窗口
    namedWindow("Kalman Filter Visualization");

    // 执行模拟和滤波
    for (int i = 0; i < 100; ++i) {
        // 获取真实值
        Eigen::Matrix<double, 2, 1> trueValue = kalmanSimulator.getTrueValue();

        // 获取滤波后的测量值
        Eigen::Matrix<double, 2, 1> kalmanFilteredMeasurement = kalmanSimulator.getKalmanFilteredMeasurement();

        // 可视化
        Mat visualization = Mat::zeros(500, 500, CV_8UC3);
        Point truePoint(trueValue(0, 0) * 50 + 250, trueValue(1, 0) * 50 + 250);
        Point measuredPoint(kalmanFilteredMeasurement(0, 0) * 50 + 250, kalmanFilteredMeasurement(1, 0) * 50 + 250);

        circle(visualization, truePoint, 5, Scalar(0, 0, 255), -1);  // 真实值用红色点表示
        circle(visualization, measuredPoint, 5, Scalar(0, 255, 0), -1);  // 测量值用绿色点表示

        imshow("Kalman Filter Visualization", visualization);
        waitKey(50);  
    }

    return 0;
}