#include <iostream>
#include <Eigen/Dense>
#include <cstdlib>
#include <cmath>

template<typename T, int x>
class Simulator {
private:
    double gaussianRandom(double mean, double _variance) {
        static double V1, V2, S;
        static int phase = 0;
        double X;

        if (phase == 0) {
            do {
                double U1 = (double)rand() / RAND_MAX;
                double U2 = (double)rand() / RAND_MAX;

                V1 = 2 * U1 - 1;
                V2 = 2 * U2 - 1;
                S = V1 * V1 + V2 * V2;
            } while (S >= 1 || S == 0);

            X = V1 * sqrt(-2 * log(S) / S);
        }
        else {
            X = V2 * sqrt(-2 * log(S) / S);
        }

        phase = 1 - phase;

        return X * _variance + mean;
    }

    Eigen::Matrix<T, x, 1> x0;
    double variance;

public:
    Eigen::Matrix<T, x, 1> getMeasurement(double t = 0) {
        Eigen::Matrix<T, x, 1> theoretical;
        Eigen::Matrix<T, x, 1> measurement;
        Eigen::Matrix<T, x, 1> noise;

        // 选择运动模型（默认为静止）
        // 取消注释所需的运动模型
        // theoretical = x0; // 静止
        // theoretical = x0 + velocity * t; // 匀速运动
        theoretical = x0 + velocity * t + 0.5 * acceleration * t * t; // 匀加速运动

        noise = Eigen::Matrix<T, x, 1>::Zero();
        for (int i = 0; i < x; i++) {
            noise(i, 0) = gaussianRandom(0, this->variance);
        }

        measurement = theoretical + noise;
        return measurement;
    }

    explicit Simulator(Eigen::Matrix<T, x, 1> x0, double variance,
        Eigen::Matrix<T, x, 1> velocity = Eigen::Matrix<T, x, 1>::Zero(),
        Eigen::Matrix<T, x, 1> acceleration = Eigen::Matrix<T, x, 1>::Zero()) {
        this->x0 = x0;
        this->variance = variance;
        this->velocity = velocity;
        this->acceleration = acceleration;
    }

    // 添加速度和加速度成员
    Eigen::Matrix<T, x, 1> velocity;
    Eigen::Matrix<T, x, 1> acceleration;
};

// 低通滤波器类
template <typename T, int x>
class LowPassFilter {
private:
    Eigen::Matrix<T, x, 1> filteredData;
    double alpha; // 滤波器系数

public:
    explicit LowPassFilter(double alpha) : alpha(alpha) {
        filteredData = Eigen::Matrix<T, x, 1>::Zero();
    }

    Eigen::Matrix<T, x, 1> filter(const Eigen::Matrix<T, x, 1>& input) {
        filteredData = alpha * input + (1 - alpha) * filteredData;
        return filteredData;
    }
};

int main() {
    // 创建仿真器
    Simulator<double, 2>* simulator;
    simulator = new Simulator<double, 2>(Eigen::Vector2d(0, 0), 5, Eigen::Vector2d(1, 0.5));

    // 创建低通滤波器
    LowPassFilter<double, 2> lowPassFilter(0.1);

    // 模拟和过滤数据
    for (int i = 0; i < 10; ++i) {
        Eigen::Vector2d measurement = simulator->getMeasurement(i);
        Eigen::Vector2d filteredMeasurement = lowPassFilter.filter(measurement);

        // 输出原始测量和过滤值
        std::cout << "Measurement: " << measurement.transpose() << " | Filtered: " << filteredMeasurement.transpose() << std::endl;
    }

    delete simulator; 

    return 0;
}
