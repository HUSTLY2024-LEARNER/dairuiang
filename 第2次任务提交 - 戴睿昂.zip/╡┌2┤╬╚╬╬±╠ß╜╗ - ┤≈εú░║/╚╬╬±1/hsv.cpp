#include<opencv2/opencv.hpp>
using namespace cv;
#include<iostream>
using namespace std;
int main()
{
	Mat rgb = imread("test.jpg");//����ʾԭͼƬ
		imshow("rgb", rgb);
		int width = rgb.cols;
		int height = rgb.rows;//��ȡԭͼƬ�ĳ���
		Mat hsv(height, width, CV_8UC3);//3ͨ���Ĳ�ɫ
		for (int i = 0; i < height; i++)//�������ص�
		{
			for (int j = 0; j < width; j++)
			{
				Vec3b rgb1 = rgb.at<Vec3b>(i, j);//at���÷�
				uchar R = rgb1[2];
				uchar G = rgb1[1];
				uchar B = rgb1[0];//�˴�һ��Ҫע��˳�򣡣���
				float V = max(R,max(G,B));
				float minrgb = min(R,min(G,B));
				float delta = V - minrgb;
				float S, H;
				S = delta / (float)(fabs(V) + FLT_EPSILON);
				delta = (float)(60.0 / (delta + FLT_EPSILON));
				//���ù�ʽ
				if (V == B)   //V=B
				{
					H = 240.0 + (R - G) * delta;
				}
				else if (V == G)  //V=G
				{
					H = 120.0 + (B - R) * delta;
				}
				else if (V == R)   //V=R
				{
					H = (G - B) * delta;
				}


				H = (H < 0.0) ? (H + 360.0) : H;
				Vec3b hsv1;
				hsv1[0] = (uchar)(H / 2);;
				hsv1[1] = (uchar)(S * 255);
				hsv1[2] = (uchar)(V * 255);//hsvֵ��Ҫ���������ʹ��
				hsv.at<Vec3b>(i, j) = hsv1;//�����hsv��
			}
		}
		imshow("hsv", hsv);
		waitKey(0);
	return 0;
}