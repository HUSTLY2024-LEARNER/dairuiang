#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <iostream>

int main() {
    // 读取图像
    cv::Mat image = cv::imread("1_whole.png");

    // 定义3D坐标点
    std::vector<cv::Point3f> objectPoints;

    
    objectPoints.push_back(cv::Point3f(0, 0, 0));    
    objectPoints.push_back(cv::Point3f(1, 0, 0));    
    objectPoints.push_back(cv::Point3f(0, 1, 0));    
    objectPoints.push_back(cv::Point3f(1, 1, 0));    

    // 定义相机矩阵（内参矩阵）
    cv::Mat cameraMatrix = (cv::Mat_<double>(3, 3) << 1900, 0, 960, 0, 1900, 540, 0, 0, 1);

   
    cv::Mat distCoeffs = cv::Mat::zeros(5, 1, CV_64F);

    // 使用Shi-Tomasi角点检测器来获取2D坐标点
    std::vector<cv::Point2f> imagePoints;
    cv::Mat grayImage;
    cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);  
    int maxCorners = 4;  
    double qualityLevel = 0.01; 
    double minDistance = 10;  
    cv::goodFeaturesToTrack(grayImage, imagePoints, maxCorners, qualityLevel, minDistance);

    // 用solvePnP进行PnP解算
    cv::Mat rvec, tvec;
    cv::solvePnP(objectPoints, imagePoints, cameraMatrix, distCoeffs, rvec, tvec);

    
    std::cout << "R = " << rvec << std::endl;
    std::cout << "T =" << tvec << std::endl;

    return 0;
}