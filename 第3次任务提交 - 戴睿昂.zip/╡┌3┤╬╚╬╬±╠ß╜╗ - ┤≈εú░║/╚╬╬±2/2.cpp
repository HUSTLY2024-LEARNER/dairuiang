#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

int main() {
    // 读取待去畸变的图像
    cv::Mat distortedImage = cv::imread("distorted.png");

    // 畸变参数
    double k1 = -0.28340811, k2 = 0.07395907, p1 = 0.00019359, p2 = 1.76187114e-05;

    // 内参
    double fx = 458.654, fy = 457.296, cx = 367.215, cy = 248.375;

    // 获取图像尺寸
    int width = distortedImage.cols;
    int height = distortedImage.rows;

    // 创建一个新的图像来存储去畸变后的结果
    cv::Mat undistortedImage = cv::Mat::zeros(height, width, distortedImage.type());

    // 去畸变
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            double x_distorted = (x - cx) / fx;
            double y_distorted = (y - cy) / fy;
            double r2 = x_distorted * x_distorted + y_distorted * y_distorted;
            double x_undistorted = x_distorted * (1 + k1 * r2 + k2 * r2 * r2) + 2 * p1 * x_distorted * y_distorted + p2 * (r2 + 2 * x_distorted * x_distorted);
            double y_undistorted = y_distorted * (1 + k1 * r2 + k2 * r2 * r2) + p1 * (r2 + 2 * y_distorted * y_distorted) + 2 * p2 * x_distorted * y_distorted;

            int x_undistorted_pixel = static_cast<int>(x_undistorted * fx + cx);
            int y_undistorted_pixel = static_cast<int>(y_undistorted * fy + cy);

            // 检查是否在图像边界内
            if (x_undistorted_pixel >= 0 && x_undistorted_pixel < width && y_undistorted_pixel >= 0 && y_undistorted_pixel < height) {
                undistortedImage.at<cv::Vec3b>(y, x) = distortedImage.at<cv::Vec3b>(y_undistorted_pixel, x_undistorted_pixel);
            }
        }
    }

    // 显示去畸变后的图像
    cv::imshow("Undistorted Image", undistortedImage);
    cv::waitKey(0);

    // 保存去畸变后的图像
    cv::imwrite("undistorted.png", undistortedImage);

    return 0;
}