#include <eigen3/Eigen/Dense>
#include <opencv2/viz.hpp>

int main() {
    // 定义欧拉角
    cout <<"roll=" << endl;
    cin >> double roll ;   
    cout <<"pitch=" << endl;
    cin >> double pitch ;  
    cout <<"yaw" << endl;
    cin >> double yaw ;   

    // 使用Eigen库创建旋转矩阵
    Eigen::Matrix3d mat1;
    mat1 = Eigen::AngleAxisd(roll, Eigen::Vector3d::UnitX())
                    * Eigen::AngleAxisd(pitch, Eigen::Vector3d::UnitY())
                    * Eigen::AngleAxisd(yaw, Eigen::Vector3d::UnitZ());

    cv::viz::Viz3d myWindow("1");
    cv::viz::WCoordinateSystem world_coor(1.0);
    myWindow.showWidget("2", world_coor);
    cv::Affine3d pose(mat1);
    cv::viz::WCoordinateSystem rotation_coor(0.5);
    myWindow.showWidget("Rotation", rotation_coor, pose);

  
    myWindow.spin();

    return 0;
}