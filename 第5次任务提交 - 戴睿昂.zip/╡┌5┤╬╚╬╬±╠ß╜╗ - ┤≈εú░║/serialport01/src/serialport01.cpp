﻿
#include <memory>//自动释放内存的智能指针
#include <boost/asio.hpp>
#include<iostream>
class BasicSerialPort
{
public:
    // 定义大小类型的别名
    using SizeType = unsigned long long;

    // 纯虚函数，用于读写，连接断联，查询链接信息
    virtual void Connect() = 0;
    virtual void Disconnect() = 0;
    virtual bool GetIsConnected() = 0;
    virtual SizeType Read(void* head, SizeType size) = 0;
    virtual SizeType Write(void* head, SizeType size) = 0;
};

class SerialPort : public BasicSerialPort
{
    std::unique_ptr<boost::asio::serial_port> SerialPointer; //串口独占的智能指针，这个指针是传输的数据的地址
    bool IsConnected{ false }; // 连接状态的变量

public:
    // 构造函数接受一个io_context引用以创建串口
    SerialPort(boost::asio::io_context& ioContext) :
        SerialPointer(std::make_unique<boost::asio::serial_port>(ioContext))
    {
    }

    // 覆盖函数以建立与串口的连接
    void Connect() override
    {
        SerialPointer->open("COM3"); // 打开COM3串口
        SerialPointer->set_option(boost::asio::serial_port::stop_bits(boost::asio::serial_port::stop_bits::one)); // 配置停止位
        SerialPointer->set_option(boost::asio::serial_port::baud_rate(9600)); // 设置波特率
        SerialPointer->set_option(boost::asio::serial_port::parity(boost::asio::serial_port::parity::none)); // 设置奇偶校验为无
        SerialPointer->set_option(boost::asio::serial_port::character_size(8)); // 设置字符大小为8位
        SerialPointer->set_option(boost::asio::serial_port::flow_control(boost::asio::serial_port::flow_control::none)); // 设置流控制为无
        //这一段是串口连接的基本配置，在asio中有对应的函数，connect是进行链接的关键步骤
    }

    // 从串口断开连接
    void Disconnect() override
    {
        SerialPointer->close(); // 关闭串口
    }

    // 检查串口是否连接
    bool GetIsConnected() override
    {
        return SerialPointer->is_open(); // 返回串口是否打开
    }

    // 从串口读取数据到缓冲区，asiobuffer是缓冲区
    SizeType Read(void* head, SizeType size) override
    {
        return boost::asio::read(*SerialPointer, boost::asio::buffer(head, size)); // 从串口读取数据到提供的缓冲区
    }

    //将数据从缓冲区写入串口
    SizeType Write(void* head, SizeType size) override
    {
        return boost::asio::write(*SerialPointer, boost::asio::buffer(head, size)); // 将提供的缓冲区的数据写入串口
    }
};
//read和write格式（输入/输出流地址，缓冲区），buffer（存储区域指针，字节数）会使用新的存储空间
int main()
{
    boost::asio::io_context io_context;
    SerialPort serial_port{ io_context };
    serial_port.Connect();

   
    while (true)
    {
        char buffer[4];
        buffer[3] = 0;
        std::cout << "输入要发送的数据(3位） " << std::endl;
        for (int i = 0; i < 3; i++)
        {
            std::cin >> buffer[i];
        }

        // 发送数据到串口
        std::cout << "发送数据: " << buffer << std::endl;
        serial_port.Write(buffer, 3);

        // 从串口接收数据
        char receivedBuffer[4];  // 修改为3个字符，再加一个用于存储 null 终止符
        serial_port.Read(receivedBuffer, 3);
        receivedBuffer[3] = 0;  // 添加 null 终止符，保证打印时不会读取到缓冲区以外的数据
        std::cout << "接收到的数据: " << receivedBuffer << std::endl;
    }
    
    return 0;
}